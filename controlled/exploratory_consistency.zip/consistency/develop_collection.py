from pathlib import Path
import sys,json,time
import numpy as np
from scipy.stats import binom
from method import disagreement_cost,lower_bounds
ROOT=Path(__file__).resolve().parent;P=ROOT.parent
sys.path.insert(0,str(P/'design'));from confirmation import all_designs,sample,core

data=dict(np.load(P/'boundary/frozen_models/models.npz'));p=data['p'];y=data['y'];delta=p[1:]-p[0];truth=delta[:,np.arange(len(y)),y].mean(axis=1)
libs=json.loads((P/'boundary/subset_protocol.json').read_text())['libraries'];rows=[];start=time.perf_counter();n=20000
for name,Q in all_designs(p).items():
 for seed in range(52000,52005):
  x,a,base=sample(data,Q,n,seed)
  for nu in [0,.01,.05]:
   noise=np.random.default_rng(np.random.SeedSequence([seed,833])).random(n)<nu;r=np.where(noise,1-base,base)
   cost=disagreement_cost(x,a,r,len(y));b=int(binom.ppf(.95,n,nu)) if nu else 0;trall=(1-2*nu)*truth
   for eps in [.005,.01]:
    low,lam=lower_bounds((1-2*nu)*delta,cost,b+2*int(n*eps));clean,_=lower_bounds((1-2*nu)*delta,cost,b+int(n*eps))
    for lib in libs:
     ids=lib['candidate_indices'];lo=low[ids];tr=trall[ids]
     poss=([-1] if max(lo)<=1e-9 else [])+[j for j in range(3) if tr[j]>1e-9 and tr[j]>=max(1e-9,max(np.delete(lo,j)))-1e-10]
     rows.append(dict(design=name,n=n,nu=nu,seed=seed,epsilon=eps,library=lib['name'],floor=min(core.utility(j,tr) for j in poss),clean=core.utility(core.choose(clean[ids]),tr),max_lower=float(max(lo)),noise_count=int(noise.sum()),noise_cap=b))
core.write_csv(ROOT/'collection_development.csv',rows)
import pandas as pd
s=pd.DataFrame(rows).groupby(['design','nu','epsilon'])[['floor','clean','max_lower']].mean();s.to_csv(ROOT/'collection_development_summary.csv');print(s.to_string());print('seconds',time.perf_counter()-start)
