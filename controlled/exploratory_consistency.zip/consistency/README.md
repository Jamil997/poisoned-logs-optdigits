# Exploratory shared reward-model consistency bounds

This preserved development branch constrains each finite-pool context to have one latent correct digit and permits a global number of reward disagreements. A continuous relaxation over latent labels gives a one-dimensional Lagrange-dual lower bound for each candidate's value relative to the incumbent. The implementation uses no evaluation labels. The diagnostic 2k ambiguity set covers every k-edit attack on the observed log.

This structural method did not achieve positive certified improvement with original collection in the tested development grid. Some targeted-collection cells were useful, but they did not establish improvement over the existing E4 corrected DR gate. It was therefore not promoted to a confirmation result or a headline method. The noisy extension budgets independent symmetric reward flips using a binomial upper quantile; its guarantees are conditional on that noise-budget event.

Both protocols and every development outcome are retained. This branch illustrates why shared-model constraints alone need not solve poor coverage. It is exploratory code, not a claimed completed or novel algorithm. The later controlled benchmark is a separate experiment.
