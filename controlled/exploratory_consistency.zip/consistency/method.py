"""Finite-pool shared reward-model ambiguity set; valid LP-dual lower bounds."""
import numpy as np

def disagreement_cost(x,a,r,N,A=10):
    counts=np.zeros((N,A),dtype=int);ones=np.zeros((N,A),dtype=int)
    np.add.at(counts,(x,a),1);np.add.at(ones,(x,a),r.astype(int))
    # Candidate true label y predicts reward 1 exactly when a=y.
    return ones.sum(axis=1)[:,None]+counts-2*ones

def lower_bounds(delta,cost,budget,iterations=48):
    """LP relaxation: min sum delta_xy p_xy, rows simplex, total cost<=budget.

    Return a feasible Lagrange dual value for every candidate. Computation
    needs only policy differences and reward inconsistency counts, never y.
    """
    N=cost.shape[0];assert delta.ndim==3 and delta.shape[1:]==cost.shape
    if cost.min(axis=1).sum()>budget:
        return np.full(len(delta),-np.inf),np.zeros(len(delta))
    lo=np.zeros(len(delta));hi=np.full(len(delta),4.)
    best=np.full(len(delta),-np.inf);bestlam=np.zeros(len(delta));row=np.arange(N)
    def evaluate(lam):
        v=delta+lam[:,None,None]*cost
        ix=v.argmin(axis=2);z=v.min(axis=2).sum(axis=1)-lam*budget
        chosen=cost[row[None,:],ix].sum(axis=1)
        return z/N,chosen
    for lam in [lo.copy(),hi.copy()]:
        val,_=evaluate(lam);mask=val>best;best[mask]=val[mask];bestlam[mask]=lam[mask]
    for _ in range(iterations):
        mid=(lo+hi)/2;val,used=evaluate(mid);mask=val>best;best[mask]=val[mask];bestlam[mask]=mid[mask]
        lo=np.where(used>budget,mid,lo);hi=np.where(used>budget,hi,mid)
    # Dual values are valid for any lambda>=0 even without numerical optimality.
    return best-1e-12,bestlam

if __name__=='__main__':
 from pathlib import Path
 import sys,json,time
 ROOT=Path(__file__).resolve().parent;P=ROOT.parent
 sys.path.insert(0,str(P/'security'));import experiment as core
 data=dict(np.load(P/'boundary/frozen_models/models.npz'));p=data['p'];y=data['y'];mu=.8*p[0]+.02
 delta=p[1:]-p[0];truth=delta[:,np.arange(len(y)),y].mean(axis=1)
 libs=json.loads((P/'boundary/subset_protocol.json').read_text())['libraries'];rows=[];start=time.perf_counter()
 for n in [5000,20000]:
  for seed in range(51000,51005):
   x,a,r=core.sample_log(data,mu,n,.2,seed);cost=disagreement_cost(x,a,r,len(y))
   for eps in [.005,.01]:
    low,lam=lower_bounds(delta,cost,2*int(n*eps));clean,_=lower_bounds(delta,cost,int(n*eps))
    for lib in libs:
     ids=lib['candidate_indices'];lo=low[ids];tr=truth[ids]
     possible=([-1] if max(lo)<=1e-9 else [])+[j for j in range(3) if tr[j]>1e-9 and tr[j]>=max(1e-9,max(np.delete(lo,j)))-1e-10]
     rows.append(dict(n=n,seed=seed,epsilon=eps,library=lib['name'],floor=min(core.utility(j,tr) for j in possible),clean=core.utility(core.choose(clean[ids]),tr),max_lower=float(max(lo))))
 core.write_csv(ROOT/'development.csv',rows)
 import pandas as pd
 print(pd.DataFrame(rows).groupby(['n','epsilon'])[['floor','clean','max_lower']].mean());print('seconds',time.perf_counter()-start)
